### 在线相册

1. 双击打开 controller/router.js 文件，找到最下方的 doPost 方法，根据注释提示补全代码，体验智能代码补全功能，代码补全候选项中标记有✨符号的为代码智能补全结果。
![completion](https://img.alicdn.com/imgextra/i1/O1CN01XXDBbr1KdEPynR7L9_!!6000000001186-1-tps-1000-508.gif)

2. 在编写完代码补全示例代码后，将鼠标hover到rename函数中，智能编码将会推荐API文档信息，并且点击下方的“API文档详情”，可在侧栏查看API的官方文档、代码示例等详细信息，也可以在侧栏顶部的搜索框中主动查询API。
![document](https://img.alicdn.com/imgextra/i4/O1CN01c0fYAT21lV386jpkn_!!6000000007025-1-tps-1440-765.gif)

3. 打开终端（顶部工具栏：终端 -> 新终端），依次输入以下命令启动服务

```
npm install
node app.js
```

4. 通过右侧工具栏的"空间服务预览"功能，成功映射端口后，可在线预览页面功能

![avatar](https://img.alicdn.com/imgextra/i4/O1CN01pZMVaS1K2ajWtj5gr_!!6000000001106-2-tps-499-287.png)
  