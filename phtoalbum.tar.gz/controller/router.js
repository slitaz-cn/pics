var file = require("../models/file.js");
var formidable = require("formidable");
var path = require("path");
var fs = require("fs");
var sd = require("silly-datetime");

exports.showIndex = function (req, res, next) {
  file.getAllAlbums(function (err, allAlbums) {
    if (err) {
      next();
      return;
    }
    res.render("index", {
      albums: allAlbums,
    });
  });
};

exports.showAlbum = function (req, res, next) {
  var albumName = req.params.albumName;
  file.getAllImagesByAlbumName(albumName, function (err, imagesArray) {
    if (err) {
      next();
      return;
    }
    res.render("album", {
      albumname: albumName,
      images: imagesArray,
    });
  });
};

exports.showUp = function (req, res) {
  file.getAllAlbums(function (err, albums) {
    res.render("up", {
      albums: albums,
    });
  });
};

exports.doPost = function (req, res) {
  var form = new formidable.IncomingForm();
  var tmpDir = path.join(__dirname, '..', 'tmp');
  form.uploadDir = tmpDir;
  form.parse(req, function (err, fields, files, next) {
    if (err) {
      next();
      return;
    }
    var size = parseInt(files.picture.size);
    if (size > 5000000) {
      res.send("图片尺寸应该小于5M");
      fs.unlink(files.picture.path);
      return;
    }
    var ttt = sd.format(new Date(), "YYYYMMDDHHmmss");
    var ran = parseInt(Math.random() * 89999 + 10000);
    var extname = path.extname(files.picture.name);
    var floder = fields.floder;
    var oldpath = files.picture.path;
    var newpath = path.join(__dirname, "../uploads", floder, ttt + ran + extname);

	fs.copyFile(oldpath, newpath, function (err) {
      if (err) {
        console.error("复制文件失败：", err);
        res.send("复制文件失败");
        return;
      }
     fs.unlink(oldpath, function (err) {
        if (err) {
          console.error("删除原始文件失败：", err);
          res.send("删除原始文件失败");
          return;
        }
      const htmlResponse = `
          <!DOCTYPE html>
          <html>
          <head>
            <title>文件上传成功</title>
          </head>
          <body>
            <h3>文件上传成功！</h3>
            <p>点击下面的按钮返回上一页：</p>
            <button onclick="goBack()">返回上一页</button>

            <script>
              function goBack() {
                window.history.back();
              }
            </script>
          </body>
          </html>
        `;
        res.send(htmlResponse);
    });
   });
  });
  return;
};
